"""
Dummy example
=======================
we test the sphinx gallery
"""

import matplotlib.pyplot as plt

_ = plt.plot(range(100), range(100), 'r*-')
